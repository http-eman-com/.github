require 'sinatra'
require 'stripe'

# This is your test secret API key.
Stripe.api_key = 'sk_test_51OAeZ3Ey0IOS7SAL1VHpOstZxOTRFgPV35Uh5Nu1wpsYO6D2by6DPwMfoK5GNnhimwOKU91Ysdy2IVlFPh9h3mZH007hmwZQnD'

set :root, File.dirname(__FILE__)
set :public_folder, -> { File.join(root, 'public') }
set :static, true
set :port, 4242

def create_location
  Stripe::Terminal::Location.create({
    display_name: 'HQ',
    address: {
      line1: '1272 Valencia Street',
      city: 'San Francisco',
      state: 'CA',
      country: 'US',
      postal_code: '94110',
    }
  })
end

get '/' do
  redirect '/index.html'
end



# The ConnectionToken's secret lets you connect to any Stripe Terminal reader
# and take payments with your Stripe account.
# Be sure to authenticate the endpoint for creating connection tokens.
post '/connection_token' do
  content_type 'application/json'

  connection_token = Stripe::Terminal::ConnectionToken.create
  {secret: connection_token.secret}.to_json
end

post '/create_payment_intent' do
  content_type 'application/json'
  data = JSON.parse(request.body.read)

  # For Terminal payments, the 'payment_method_types' parameter must include
  # 'card_present'.
  # To automatically capture funds when a charge is authorized,
  # set `capture_method` to `automatic`.
  intent = Stripe::PaymentIntent.create(
    amount: data['amount'],
    currency: 'usd',
    payment_method_types: [
      'card_present',
    ],
    capture_method: 'manual',
  )

  intent.to_json
end



post '/capture_payment_intent' do
  data = JSON.parse(request.body.read)

  intent = Stripe::PaymentIntent.capture(data['payment_intent_id'])

  intent.to_json
end

